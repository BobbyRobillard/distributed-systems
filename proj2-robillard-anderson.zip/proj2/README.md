# Proj2

**Team Members:**
- Robert Robillard
- William B. Anderson

**Compile With:**
- $ mix escript.build
- $ ./proj2 <num_nodes> <topology> <algorithm>

**What is Working:**
- Everything

**What is the largest network you managed to deal with for each type of
 topology and algorithm:**
- We managed to run with 500 nodes in each topology in each algorithm.
Past that it simply took too long to obtain results from given the time constraints.
Should we have used a more powerful machine we probably could have pushed 1000 without issues.

**Note:**
- There are is an additional folder "output_data" which contains all the raw data
and xlsx from which the graphs in our report are derived.
