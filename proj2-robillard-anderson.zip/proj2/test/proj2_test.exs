defmodule Proj2Test do
  use ExUnit.Case
  doctest Proj2

  test "greets the world" do
    assert Proj2.hello() == :world
  end
end
